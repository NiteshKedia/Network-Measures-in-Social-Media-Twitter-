credentials.ConsumerKey = 'VeVzP9Hjd2DzLD0rV6nWYQ';
credentials.ConsumerSecret = 'XCOG27tJbwbWLDAGBMQm9BeuwCsiIyBiwPILAZ4qo';
credentials.AccessToken = '400213917-MhrVhgyU0YsG6dGQTpv2UnCHCqDgw0JExIGNhiwy';
credentials.AccessTokenSecret = 'xydhgw4X4eCqOuIoQ0OJUUHSkjYOPz5vdH7pEfAqQ';
tw = twitty(credentials);